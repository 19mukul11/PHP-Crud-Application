<div id="header">
            <h1>PHP - MySQL CRUD Operations</h1>
            <ul>
                <li><a href="index.php">Home</a></li>
                <li><a href="add.php">Add</a></li>
                <li><a href="read.php">Read</a></li>
                <li><a href="update.php">Update</a></li>
                <li><a href="delete.php">Delete</a></li>
            </ul>
 </div>